package model;

public class ResultAndProblem {
	 private String result;
	 private String problem;
	    public String getResult() {
	        return result;
	    }
	    public String getProblem() {
	        return problem;
	    }
	    public void setResult(String result) {
	        this.result = result;
	    }

	    

	    public void setProblem(String problem) {
	        this.problem = problem;
	    }
	    
	

}
